/** 앱 실행방법 */
1. 웹브라우저(Chrome 또는 Safari)를 실행하고
2. launcher.html 파일을 웹 브라우저로 Drag&Drop한다.
3. launcher.html뒤에 다음과 같이 실행할 앱의 이름(scene)을 기술한다.
    [경로]/launcher.html?app=scene

