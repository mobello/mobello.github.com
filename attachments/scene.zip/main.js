/**
 * Main Controller Class. This class is registered config.json 
 * configuration file
 */
$class('sample.CustomController').extend(tau.ui.SceneController).define({

  loadScene: function () {
    var scene = this.getScene(),
        label = new tau.ui.Label({text: 'Right here'}),
        button = new tau.ui.Button({label: 'Touch Me!'});
    // button.setLabel('Touch Me!'); // you can set label in this way
    button.onEvent(tau.rt.Event.TAP, this.handleTouch, this); // register event listener
    scene.add(label);
    scene.add(button);
  },
  
  /**
   * event listener invoked when an user touches the button component
   */
  handleTouch: function (e, payload) {
    var btn = e.getSource();
    tau.alert(btn.getLabel() + ' is touched');
  }
});