$class('tau.sample.ani.SceneCtrl').extend(tau.ui.SceneController).define({
  
  loadScene: function () {
    var scene = this.getScene();
    var button = new tau.ui.Button({
      label : 'animate'      
    });
    button.onEvent(tau.rt.Event.TAP, this.handleTap, this);
    
    var Button1 = new tau.ui.Button({
      id : 'Button1',
      label : 'Button1'
    });
        
    var Button2 = new tau.ui.Button({
      id : 'Button2',
      label : 'Button2'
    });
    
    var Button3 = new tau.ui.Button({
      id : 'Button3',
      label : 'Button3',
      styles : {display: 'none'}
    });
    
    var Button4 = new tau.ui.Button({
      id : 'Button4',
      label : 'Button4'
    });
    
    scene.add(button);
    scene.add(Button1);
    scene.add(Button2);
    scene.add(Button3);
    scene.add(Button4);
  },
 
  handleTap: function () {
    var scene = this.getScene();    
    var Button1 = scene.getComponent('Button1');
    var Button2 = scene.getComponent('Button2');
    var Button3 = scene.getComponent('Button3');
    var Button4 = scene.getComponent('Button4');
    
    
    /** Transition **/   
    var tran = new tau.fx.Transition({duration: "1000ms"});
    tran.setStyle("width", "200px");
    tran.setStyle("height","200px",{timingFunction : "cubic-bezier(0, 1, 0, 1)", duration: "1500ms"});
    tran.setStyle("color","red",{timingFunction : "ease-out", duration: "1500ms"});
    tran.setStyle("margin","20px",{timingFunction : "ease-out", duration: "1500ms"});
    tran.setStyle("padding","20px",{timingFunction : "ease-in", duration: "1500ms"});
    tran.animate(Button1.getDOM());
    /** Animation **/
    var ani = new tau.fx.Animation({
    from : {'background': 'red'},
    to : {'background': 'yellow'}
    }, {
      timingFunction : 'ease-out',
      duration : 2500,
      override : true,
      iterationCount : 2,
      delay : 1000
      });
    ani.animate(Button2.getDOM());
    /** Buitin **/
    tau.fx.fadeIn(Button3.getDOM(),{duration : 500});
    tau.fx.fadeOut(Button4.getDOM(),{duration : 500});
  }
  
  
});